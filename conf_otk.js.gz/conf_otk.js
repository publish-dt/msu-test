hostname = "";
extHost = "http://2.56.88.201:8080";
dnsLinks = "";
StaticResourcesHost = "http://2.56.88.201:8080";