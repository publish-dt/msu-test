extHost = "";
dnsLinks = "";
StaticResourcesHost = "";