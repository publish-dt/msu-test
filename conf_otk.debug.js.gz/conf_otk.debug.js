hostname = "";
extHost = ""; // https://bv.rostok:7272
dnsLinks = "";
StaticResourcesHost = "";